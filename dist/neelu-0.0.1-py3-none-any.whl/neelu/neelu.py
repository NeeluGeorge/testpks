def printhi():
    print('Hi printing from library,updated one')