def printhi():
    print('Hi printing from library')